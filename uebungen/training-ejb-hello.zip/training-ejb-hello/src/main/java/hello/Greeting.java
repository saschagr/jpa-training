package hello;

import jakarta.ejb.Local;

@Local
public interface Greeting {
	
	String greeting();

}
