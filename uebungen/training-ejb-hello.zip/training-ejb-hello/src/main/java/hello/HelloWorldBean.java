/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package hello;

import jakarta.ejb.EJB;
import jakarta.ejb.Remote;
import jakarta.inject.Inject;

@jakarta.ejb.Stateless(name = "HelloWorld")
@Remote(value = HelloWorld.class)
public class HelloWorldBean implements HelloWorld {
	
	//@Inject
	@EJB	
	private Greeting greeting;
	

	@Override
	public String hello(String who) {
		System.out.println("Say hello to " + who);
		
		
		return greeting.greeting() +  " "  + who; 
	}
}
